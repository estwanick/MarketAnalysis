.. automodule:: scipy.io.arff
