.. _optimize.minimize-bfgs:

minimize(method='BFGS')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize.optimize._minimize_bfgs
   :method: BFGS
