.. include:: ../release/0.15.1-notes.rst
