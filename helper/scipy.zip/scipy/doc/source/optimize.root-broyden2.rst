.. _optimize.root-broyden2:

root(method='broyden2')
--------------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._root._root_broyden2_doc
   :method: broyden2
