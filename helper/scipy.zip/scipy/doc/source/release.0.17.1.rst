.. include:: ../release/0.17.1-notes.rst
