.. automodule:: scipy.spatial

.. toctree::
   :hidden:

   spatial.distance
