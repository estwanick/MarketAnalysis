.. automodule:: scipy.linalg

.. toctree::
   :hidden:

   linalg.blas
   linalg.lapack
   linalg.cython_blas
   linalg.cython_lapack
   linalg.interpolative
