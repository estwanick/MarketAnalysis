.. automodule:: scipy.io

.. toctree::
   :hidden:

   scipy.io.arff
