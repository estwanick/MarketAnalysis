.. automodule:: scipy.ndimage
