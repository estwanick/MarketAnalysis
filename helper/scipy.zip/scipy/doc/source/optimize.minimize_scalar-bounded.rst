.. _optimize.minimize_scalar-bounded:

minimize_scalar(method='bounded')
------------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize_scalar
   :impl: scipy.optimize.optimize._minimize_scalar_bounded
   :method: bounded
